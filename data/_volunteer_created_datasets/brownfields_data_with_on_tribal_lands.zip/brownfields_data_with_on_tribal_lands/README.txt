Documentation for brownfields_data_with_on_tribal_lands.csv

1. Generating the dataset
   This dataset was produced by the script: scripts/rebecca-burwei/ add_OnTribalLands_indicator_to_brownfields_data.r
   See that script for more information about how the data was generated. 
   Running that script to generate the data took 8 hours.

2. `On Tribal Lands` field
   This field is 
   * TRUE if a property was found to be on tribal lands based on longitude and latitude
   * FALSE if not
   * NA if the property's longitude or latitude was missing

   > summary(dat$On.Tribal.Lands)
   Mode   FALSE    TRUE    NA's 
logical   74205    3996     326 
